# AUDL Dashboard

[link to the dashboard](https://yukikongju-audl-dashboard-home-z60xei.streamlit.app/Player_Throwing_Selection)

All data where fecthed from the [unofficial AUDL api](https://github.com/yukikongju/audl)


