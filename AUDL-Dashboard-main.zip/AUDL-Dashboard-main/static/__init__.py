import static.parameters
